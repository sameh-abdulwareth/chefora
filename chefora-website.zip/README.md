# CHEFORA | شيفورا — partnership website

A bilingual (Arabic/English) marketing and B2B-partnership site for CHEFORA,
built with Next.js. It introduces the brand, shows the product range, and
routes interested companies into an agency/distribution inquiry — without
claiming any business facts (sales figures, branch counts, territory
availability, certifications) that weren't in the supplied brand materials.

- **Brand name:** CHEFORA (English) / شيفورا (Arabic). The two "CHIFORA"
  logo files that were attached alongside the brand PDF were mis-exports and
  are **not** used anywhere in this build — every logo asset here was
  re-extracted from the brand identity PDF, which consistently spells the
  name CHEFORA.
- **Languages:** Arabic (default, RTL) and English (LTR), at `/ar/...` and
  `/en/...`. The language switch keeps you on the same page.
- **Stack:** Next.js 16 (App Router, Turbopack) + TypeScript + Tailwind CSS 4.

---

## 1. Running it locally

```bash
npm install
npm run dev
```

Open <http://localhost:3000> — it redirects to `/ar` or `/en` based on your
browser's language.

Other scripts:

```bash
npm run build   # production build (also type-checks and prerenders every page)
npm run start   # serve the production build — run `build` first
npm run lint    # ESLint
```

No environment variables are required to run or build the site. Everything
that depends on one (see §4) has a safe, empty fallback, so nothing
fabricated is ever shown to a visitor — a missing contact email simply
doesn't render, rather than showing a placeholder.

---

## 2. Editing text

All copy lives in two dictionary files, kept in sync by shape:

- `src/i18n/dictionaries/en.ts` — English
- `src/i18n/dictionaries/ar.ts` — Arabic

Each is a plain nested object (`home.hero.title`, `partnerships.value.items`,
etc.). To change any text on the site, find the matching key in both files
and edit the string — no other code needs to change. TypeScript will error
at build time if the two files' shapes drift apart, so it's safe to edit
without accidentally breaking the other language.

Page-level `<title>`/meta description text is in the `meta` section of each
dictionary.

---

## 3. Editing images and product categories

### Product categories (Home + Products page)

Edit `src/data/products.ts`. Each entry needs a stable `id`
(`"cookies" | "pastries" | "chocolate" | "frozen"`), an image path under
`/public/images/...`, and an English alt-text description. The category's
displayed title/body text is looked up from the dictionaries by `id` — add
or remove the matching entry in **both** `src/i18n/dictionaries/en.ts` and
`ar.ts` under `products.categories` when you add or remove a category here.

### Gallery

Edit `src/data/gallery.ts` — a flat list, no dictionary changes required.
Each entry has an `id`, `src`, a `category` (`store | packaging | people |
campaign`, which drives the filter tabs on the Gallery page), and a caption
in both languages inline (`caption.en` / `caption.ar`). Add, remove or
reorder entries freely; the Gallery page and the Home page's 6-image preview
both read from this same list.

### Adding a new image file

1. Drop the optimized image (see below) into the matching folder under
   `public/images/` (`products/`, `store/`, `people/`, `campaign/`,
   `gallery/`, or `logos/`).
2. Reference it by its `/images/...` path from `products.ts`, `gallery.ts`,
   or directly in a page component.

Images should be JPEG, sensibly sized (this project's photos were capped at
2400px on the long edge, quality ~86, which keeps files well under 500KB
while still looking sharp) — Next.js's built-in image optimizer (`next/image`,
used everywhere on this site) generates the actual responsive sizes served
to visitors, so you don't need to produce multiple resolutions yourself.

### Logos

`src/components/Logo.tsx` renders the wordmark. The extracted logo files are
in `public/images/logos/`:

| File | Use |
|---|---|
| `chefora-wordmark-cocoa.png` | Wordmark on light backgrounds (header) |
| `chefora-wordmark-white.png` | Wordmark on dark backgrounds (footer) |
| `chefora-lockup-primary-cream.png` | Full lockup, cream background |
| `chefora-lockup-reverse-cocoa.png` | Full lockup, cocoa background |
| `chefora-icon-c.png` | Standalone "C" icon |
| `favicon-16/32/48.png`, `apple-touch-icon.png`, `icon-192/512.png`, `icon-512-dark.png` | Favicons / app icons |

---

## 4. Contact form setup

There are two forms — General Inquiry and Partnership Request (the
partnership one has the extra company/agency fields from the brief) — both
posting to API routes (`src/app/api/contact/route.ts`,
`src/app/api/partnership/route.ts`). Both routes:

- Validate every field server-side (not just in the browser).
- Reject obvious bots via a hidden honeypot field plus a minimum-time check
  (a submission faster than a human could plausibly fill the form is
  rejected).
- Never invent or expose any CHEFORA contact email/phone — those only
  appear on the site once you set `NEXT_PUBLIC_CONTACT_EMAIL` /
  `NEXT_PUBLIC_CONTACT_PHONE`.

### Where submissions go

Copy `.env.example` to `.env.local` and set:

```bash
CONTACT_RECIPIENT_EMAIL=you@yourcompany.com
RESEND_API_KEY=re_xxxxxxxxxxxx        # from https://resend.com
RESEND_FROM_EMAIL=CHEFORA Website <onboarding@resend.dev>
```

With those set, a submission is emailed via the [Resend](https://resend.com)
API to `CONTACT_RECIPIENT_EMAIL`. **Without them**, nothing is lost —
submissions are instead appended as JSON lines to `submissions/general.jsonl`
and `submissions/partnership.jsonl` on the server, and a warning is printed
to the server log so you notice it's not wired up yet. This is intentional:
the site is fully functional out of the box, and switching to real email
delivery is a config change, not a code change.

To use a different email provider, edit `deliverSubmission()` in
`src/lib/notify.ts` — it's the single place that decides how a submission is
delivered.

---

## 5. Deploying

This is a standard Next.js app — deploy it anywhere that runs Next.js
(Vercel, a Node server, Docker, etc.). The general shape:

```bash
npm install
npm run build
npm run start   # or: next start -p <port>
```

Set the environment variables from `.env.example` on whatever platform you
deploy to (most platforms — Vercel, Railway, Render, etc. — have an
"Environment Variables" settings screen; on a plain server, put them in
`.env.local` or export them in your process manager).

Before going live, set at minimum:
- `NEXT_PUBLIC_SITE_URL` — your real domain, used in canonical URLs, Open
  Graph tags and `sitemap.xml`.
- `CONTACT_RECIPIENT_EMAIL` + `RESEND_API_KEY` — so form submissions actually
  reach someone.

---

## 6. Images used, by page

| Page | Images |
|---|---|
| Home | Hero (`gallery/hero-cookies-banner.jpg`); 4 category cards (`people/staff-team-bags-counter.jpg`, `store/storefront-display-case.jpg`, `campaign/chocolate-pour-mural.jpg`, `products/bubble-waffle-duo-street.jpg`); Identity showcase (`store/storefront-display-case.jpg`, `store/vending-kiosk.jpg`, `people/staff-packing-box.jpg`); Gallery preview (first 6 of the Gallery list below) |
| About | `people/baker-portrait-pouches.jpg` |
| Products | Same 4 category images as Home, in a larger editorial layout |
| Partnerships | `store/store-opening-ribbon.jpg` (hero), `store/vending-kiosk.jpg` (experience section) |
| Gallery (and Home preview) | All 16: `store/storefront-display-case.jpg`, `store/store-opening-ribbon.jpg`, `store/vending-kiosk.jpg`, `products/dessert-box-takeaway.jpg`, `products/bubble-waffle-duo-street.jpg`, `people/staff-male-cookies.jpg`, `people/staff-team-bags-counter.jpg`, `people/staff-packing-box.jpg`, `people/staff-team-selfie.jpg`, `people/baker-portrait-pouches.jpg`, `gallery/hero-cookies-banner.jpg`, `campaign/bubble-waffle-cap.jpg`, `campaign/me-you-cookie-heads.jpg`, `campaign/chocolate-pour-mural.jpg`, `campaign/giant-bucket-walk-side.jpg`, `campaign/giant-bucket-head-walk.jpg` |
| Header / Footer | `logos/chefora-wordmark-cocoa.png`, `logos/chefora-wordmark-white.png` |
| Favicons / app icons | `logos/favicon-16.png`, `favicon-32.png`, `favicon-48.png`, `apple-touch-icon.png`, `icon-192.png`, `icon-512.png`, `icon-512-dark.png` |

Every photo above came from the attached brand photography — none were
generated or sourced elsewhere. `logos/chefora-mural-icon-photo.jpg` and
`logos/chefora-icon-c.png` are extracted/available assets not currently
placed on a page; they're there if you want to use the icon somewhere new.

---

## 7. Before this goes live — information still needed

The site is fully functional and shows nothing false, but the following
real business information was not in the supplied brand materials and
should be filled in before publishing (this list also lives in code, as
`launchTodos` in `src/data/site.ts`, so it stays next to what depends on it):

1. Official contact email address for general and partnership inquiries.
2. Official contact phone number (if the brand wants one published).
3. Destination inbox for form submissions (`CONTACT_RECIPIENT_EMAIL`).
4. Production domain name (`NEXT_PUBLIC_SITE_URL`).
5. Confirmed social media handles, if any are official yet.
6. Legal entity name, address and registration details for the Privacy
   Policy and Terms of Use.
7. Confirmation of which countries/territories are open for agency or
   distribution discussions — the site intentionally never claims a
   territory is available.
8. Final legal review and sign-off of the draft Privacy Policy and Terms of
   Use pages (both are clearly marked as drafts on the site itself).
9. A production email-sending provider's credentials (see §4).

---

## 8. Notes on structure

- `src/i18n/` — locale config, route slugs (identical across languages, so
  switching language never changes the URL shape), and the two dictionaries.
- `src/data/` — all editable content that isn't prose (products, gallery,
  site-wide config/TODOs).
- `src/components/` — UI building blocks.
- `src/components/forms/` — the two forms, shared field components, and
  client-side validation.
- `src/lib/` — validation rules and the submission-delivery logic.
- `src/app/[locale]/...` — the actual pages (App Router).
- `src/app/api/...` — the two form-submission endpoints.

The site respects `prefers-reduced-motion`, has visible keyboard focus
states, a skip-to-content link, per-language SEO metadata/Open Graph tags,
and a generated `sitemap.xml`/`robots.txt`.
