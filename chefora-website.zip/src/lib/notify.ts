import { promises as fs } from "fs";
import path from "path";
import { siteConfig } from "@/data/site";

type SubmissionKind = "general" | "partnership";

/**
 * Delivers a form submission.
 *
 * If RESEND_API_KEY and CONTACT_RECIPIENT_EMAIL are set, the submission is
 * emailed via the Resend API (https://resend.com). Otherwise — e.g. in local
 * development, or before those env vars are configured — the submission is
 * appended to a local JSONL log under `submissions/` so nothing is lost, and
 * a warning is printed to the server console.
 *
 * See README.md → "Contact form setup" for how to configure a real provider.
 */
export async function deliverSubmission(
  kind: SubmissionKind,
  data: Record<string, string>
): Promise<{ delivered: boolean }> {
  const apiKey = process.env.RESEND_API_KEY;
  const recipient = siteConfig.formRecipientEmail;

  if (apiKey && recipient) {
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: process.env.RESEND_FROM_EMAIL || "CHEFORA Website <onboarding@resend.dev>",
          to: [recipient],
          subject:
            kind === "partnership"
              ? `New partnership request — ${data.companyName || "Unknown company"}`
              : `New website inquiry — ${data.name || "Unknown"}`,
          text: formatPlainText(kind, data),
        }),
      });
      if (res.ok) return { delivered: true };
      console.error("[notify] Resend API responded with an error", await res.text());
    } catch (err) {
      console.error("[notify] Failed to send via Resend", err);
    }
  } else {
    console.warn(
      "[notify] RESEND_API_KEY / CONTACT_RECIPIENT_EMAIL not configured — logging submission locally instead. See README.md."
    );
  }

  await logToDisk(kind, data);
  return { delivered: false };
}

function formatPlainText(kind: SubmissionKind, data: Record<string, string>) {
  return Object.entries(data)
    .map(([key, value]) => `${key}: ${value}`)
    .join("\n");
}

async function logToDisk(kind: SubmissionKind, data: Record<string, string>) {
  try {
    const dir = path.join(process.cwd(), "submissions");
    await fs.mkdir(dir, { recursive: true });
    const file = path.join(dir, `${kind}.jsonl`);
    const line = JSON.stringify({ receivedAt: new Date().toISOString(), ...data }) + "\n";
    await fs.appendFile(file, line, "utf8");
  } catch (err) {
    // As a last resort, at least surface it in the server logs.
    console.error("[notify] Failed to log submission to disk", err, data);
  }
}
