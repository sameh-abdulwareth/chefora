export type FieldErrors<T extends string> = Partial<Record<T, string>>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function isValidEmail(value: string) {
  return EMAIL_RE.test(value.trim());
}

export function required(value: string) {
  return value.trim().length > 0;
}

export function minLength(value: string, n: number) {
  return value.trim().length >= n;
}

export type GeneralFormData = {
  name: string;
  email: string;
  message: string;
  // Honeypot — real users never fill this in.
  company_website: string;
  // Time-trap — timestamp (ms) the form was rendered, checked server-side.
  renderedAt: string;
};

export type PartnershipFormData = {
  companyName: string;
  contactName: string;
  email: string;
  phone: string;
  country: string;
  city: string;
  interest: "agency" | "distribution" | "other" | "";
  companyBrief: string;
  message: string;
  company_website: string;
  renderedAt: string;
};

export function validateGeneral(data: GeneralFormData) {
  const errors: FieldErrors<keyof GeneralFormData> = {};
  if (!required(data.name)) errors.name = "required";
  if (!required(data.email) || !isValidEmail(data.email)) errors.email = "email";
  if (!minLength(data.message, 10)) errors.message = "minLength";
  return errors;
}

export function validatePartnership(data: PartnershipFormData) {
  const errors: FieldErrors<keyof PartnershipFormData> = {};
  if (!required(data.companyName)) errors.companyName = "required";
  if (!required(data.contactName)) errors.contactName = "required";
  if (!required(data.email) || !isValidEmail(data.email)) errors.email = "email";
  if (!required(data.country)) errors.country = "required";
  if (!required(data.interest)) errors.interest = "required";
  if (!minLength(data.companyBrief, 10)) errors.companyBrief = "minLength";
  return errors;
}

export function hasErrors(errors: Record<string, string | undefined>) {
  return Object.values(errors).some(Boolean);
}
