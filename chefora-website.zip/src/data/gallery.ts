/**
 * Gallery image data. To add or remove a gallery image, add/remove an entry
 * here — no other file needs to change. `category` drives the filter tabs on
 * the Gallery page (store / packaging / people / campaign).
 */

export type GalleryCategory = "store" | "packaging" | "people" | "campaign";

export type GalleryItem = {
  id: string;
  src: string;
  category: GalleryCategory;
  caption: { en: string; ar: string };
};

export const galleryItems: GalleryItem[] = [
  {
    id: "storefront-display-case",
    src: "/images/store/storefront-display-case.jpg",
    category: "store",
    caption: { en: "Storefront display case", ar: "واجهة عرض المتجر" },
  },
  {
    id: "store-opening-ribbon",
    src: "/images/store/store-opening-ribbon.jpg",
    category: "store",
    caption: { en: "Store opening", ar: "افتتاح المتجر" },
  },
  {
    id: "vending-kiosk",
    src: "/images/store/vending-kiosk.jpg",
    category: "store",
    caption: { en: "Self-service vending kiosk", ar: "كشك البيع الذاتي" },
  },
  {
    id: "dessert-box-takeaway",
    src: "/images/products/dessert-box-takeaway.jpg",
    category: "packaging",
    caption: { en: "Takeaway dessert box", ar: "صندوق الطلبات الجاهزة" },
  },
  {
    id: "bubble-waffle-duo-street",
    src: "/images/products/bubble-waffle-duo-street.jpg",
    category: "packaging",
    caption: { en: "Bubble waffle, packed to go", ar: "بابل وافل جاهز للطلب" },
  },
  {
    id: "staff-male-cookies",
    src: "/images/people/staff-male-cookies.jpg",
    category: "people",
    caption: { en: "Fresh from the kitchen", ar: "طازج من المطبخ" },
  },
  {
    id: "staff-team-bags-counter",
    src: "/images/people/staff-team-bags-counter.jpg",
    category: "people",
    caption: { en: "The team at the counter", ar: "الفريق عند الطاولة" },
  },
  {
    id: "staff-packing-box",
    src: "/images/people/staff-packing-box.jpg",
    category: "people",
    caption: { en: "Packing with care", ar: "تغليف بعناية" },
  },
  {
    id: "staff-team-selfie",
    src: "/images/people/staff-team-selfie.jpg",
    category: "people",
    caption: { en: "Team culture", ar: "ثقافة الفريق" },
  },
  {
    id: "baker-portrait-pouches",
    src: "/images/people/baker-portrait-pouches.jpg",
    category: "people",
    caption: { en: "Baked and packed in-house", ar: "يُخبز ويُعبّأ في المكان" },
  },
  {
    id: "hero-cookies-banner",
    src: "/images/gallery/hero-cookies-banner.jpg",
    category: "campaign",
    caption: { en: "Cookies & soft serve, together", ar: "كوكيز وآيس كريم معًا" },
  },
  {
    id: "bubble-waffle-cap",
    src: "/images/campaign/bubble-waffle-cap.jpg",
    category: "campaign",
    caption: { en: "A CHEFORA kind of afternoon", ar: "عصر بطعم شيفورا" },
  },
  {
    id: "me-you-cookie-heads",
    src: "/images/campaign/me-you-cookie-heads.jpg",
    category: "campaign",
    caption: { en: "“Me / You” campaign", ar: "حملة “أنا / أنت”" },
  },
  {
    id: "chocolate-pour-mural",
    src: "/images/campaign/chocolate-pour-mural.jpg",
    category: "campaign",
    caption: { en: "Chocolate, poured generously", ar: "شوكولاتة تُسكب بسخاء" },
  },
  {
    id: "giant-bucket-walk-side",
    src: "/images/campaign/giant-bucket-walk-side.jpg",
    category: "campaign",
    caption: { en: "Bigger than life", ar: "أكبر من الحياة نفسها" },
  },
  {
    id: "giant-bucket-head-walk",
    src: "/images/campaign/giant-bucket-head-walk.jpg",
    category: "campaign",
    caption: { en: "Impossible to miss", ar: "يستحيل ألّا تلاحظها" },
  },
];
