/**
 * Central place for business-critical information that is NOT confirmed in the
 * supplied brand materials. Everything below marked TODO must be filled in
 * with real, verified information before this site is published.
 *
 * Nothing here is invented or guessed — placeholders are intentionally left
 * empty or generic so the site never shows a fabricated claim to a visitor.
 */

export const siteConfig = {
  // Canonical domain for metadata / Open Graph / sitemap generation.
  // TODO: replace with the real production domain before launch.
  siteUrl: process.env.NEXT_PUBLIC_SITE_URL || "https://www.chefora.example",

  brandName: "CHEFORA",
  brandNameAr: "شيفورا",

  // TODO: Provide official public contact details before launch.
  // Nothing is shown on the site until these are set via environment
  // variables (see README.md) so no placeholder contact info is ever
  // displayed to a visitor.
  contactEmail: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "",
  contactPhone: process.env.NEXT_PUBLIC_CONTACT_PHONE || "",

  // Where partnership/contact form submissions are delivered.
  // Configure via environment variable — see README.md "Contact form setup".
  formRecipientEmail: process.env.CONTACT_RECIPIENT_EMAIL || "",

  social: {
    // TODO: add official social profiles once confirmed.
    instagram: process.env.NEXT_PUBLIC_SOCIAL_INSTAGRAM || "",
    tiktok: process.env.NEXT_PUBLIC_SOCIAL_TIKTOK || "",
  },
} as const;

/**
 * Missing business information required before this site can go live.
 * Surfaced again in README.md — kept here too so it lives next to the code
 * that depends on it.
 */
export const launchTodos = [
  "Official contact email address for general and partnership inquiries.",
  "Official contact phone number (if the brand wants one published).",
  "Destination inbox/CRM for the contact and partnership form submissions (CONTACT_RECIPIENT_EMAIL).",
  "Production domain name for metadata, Open Graph tags and the sitemap (NEXT_PUBLIC_SITE_URL).",
  "Confirmed social media handles (Instagram, TikTok, etc.), if any are official yet.",
  "Legal entity name, address and any registration details required for the Privacy Policy and Terms of Use.",
  "Confirmation on which countries/territories are open for agency or distribution discussions (the site intentionally does not claim any territory is available).",
  "Final legal review and sign-off of the draft Privacy Policy and Terms of Use pages.",
  "A production email-sending provider (e.g. Resend, Postmark, SMTP) credentials for the contact form API route — see README.md.",
] as const;
