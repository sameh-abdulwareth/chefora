/**
 * Product category data, driving the Home and Products pages.
 * Copy lives in the i18n dictionaries (src/i18n/dictionaries) keyed by `id`;
 * this file only controls which categories exist, their order and imagery.
 *
 * To add or remove a category:
 *  1. Add/remove an entry here with a unique `id` and an image path.
 *  2. Add/remove the matching entry in `products.categories` in both
 *     src/i18n/dictionaries/en.ts and ar.ts (same `id`).
 */

export type ProductCategory = {
  id: "cookies" | "pastries" | "chocolate" | "frozen";
  image: string;
  imageAlt: string;
};

export const productCategories: ProductCategory[] = [
  {
    id: "cookies",
    image: "/images/people/staff-team-bags-counter.jpg",
    imageAlt: "CHEFORA cookies and takeaway bags at the counter",
  },
  {
    id: "pastries",
    image: "/images/store/storefront-display-case.jpg",
    imageAlt: "Croissants and baked pastries in the CHEFORA display case",
  },
  {
    id: "chocolate",
    image: "/images/campaign/chocolate-pour-mural.jpg",
    imageAlt: "Chocolate drink pour, CHEFORA campaign photography",
  },
  {
    id: "frozen",
    image: "/images/products/bubble-waffle-duo-street.jpg",
    imageAlt: "Two CHEFORA bubble waffle cups with soft serve",
  },
];
