import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { defaultLocale, locales } from "@/i18n/config";

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const pathnameHasLocale = locales.some(
    (locale) => pathname === `/${locale}` || pathname.startsWith(`/${locale}/`)
  );
  if (pathnameHasLocale) return;

  // Redirect "/" (and any locale-less path) to the default locale.
  // A lightweight Accept-Language check picks Arabic or English; everything
  // else falls back to the default (Arabic).
  const acceptLanguage = request.headers.get("accept-language") || "";
  const preferred = acceptLanguage.toLowerCase().includes("en") && !acceptLanguage.toLowerCase().includes("ar")
    ? "en"
    : defaultLocale;

  const url = request.nextUrl.clone();
  url.pathname = `/${preferred}${pathname === "/" ? "" : pathname}`;
  return NextResponse.redirect(url);
}

export const config = {
  matcher: [
    "/((?!_next|api|images|favicon.ico|robots.txt|sitemap.xml|apple-touch-icon.png|icon.png).*)",
  ],
};
