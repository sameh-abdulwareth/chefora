import { NextResponse } from "next/server";
import { validatePartnership, hasErrors, type PartnershipFormData } from "@/lib/validation";
import { deliverSubmission } from "@/lib/notify";

export async function POST(request: Request) {
  let body: Partial<PartnershipFormData>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "invalid_body" }, { status: 400 });
  }

  const data: PartnershipFormData = {
    companyName: body.companyName?.toString() ?? "",
    contactName: body.contactName?.toString() ?? "",
    email: body.email?.toString() ?? "",
    phone: body.phone?.toString() ?? "",
    country: body.country?.toString() ?? "",
    city: body.city?.toString() ?? "",
    interest: (body.interest as PartnershipFormData["interest"]) ?? "",
    companyBrief: body.companyBrief?.toString() ?? "",
    message: body.message?.toString() ?? "",
    company_website: body.company_website?.toString() ?? "",
    renderedAt: body.renderedAt?.toString() ?? "",
  };

  if (data.company_website.trim().length > 0) {
    return NextResponse.json({ ok: true });
  }

  const renderedAt = Number(data.renderedAt);
  if (Number.isFinite(renderedAt) && Date.now() - renderedAt < 1500) {
    return NextResponse.json({ ok: false, error: "too_fast" }, { status: 400 });
  }

  const errors = validatePartnership(data);
  if (hasErrors(errors)) {
    return NextResponse.json({ ok: false, errors }, { status: 422 });
  }

  const { delivered } = await deliverSubmission("partnership", {
    companyName: data.companyName,
    contactName: data.contactName,
    email: data.email,
    phone: data.phone,
    country: data.country,
    city: data.city,
    interest: data.interest,
    companyBrief: data.companyBrief,
    message: data.message,
  });

  return NextResponse.json({ ok: true, delivered });
}
