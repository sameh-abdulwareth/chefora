import { NextResponse } from "next/server";
import { validateGeneral, hasErrors, type GeneralFormData } from "@/lib/validation";
import { deliverSubmission } from "@/lib/notify";

export async function POST(request: Request) {
  let body: Partial<GeneralFormData>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "invalid_body" }, { status: 400 });
  }

  const data: GeneralFormData = {
    name: body.name?.toString() ?? "",
    email: body.email?.toString() ?? "",
    message: body.message?.toString() ?? "",
    company_website: body.company_website?.toString() ?? "",
    renderedAt: body.renderedAt?.toString() ?? "",
  };

  // Honeypot: a real visitor never fills this hidden field.
  if (data.company_website.trim().length > 0) {
    return NextResponse.json({ ok: true }); // pretend success, drop silently
  }

  // Time-trap: reject submissions completed implausibly fast (<1.5s).
  const renderedAt = Number(data.renderedAt);
  if (Number.isFinite(renderedAt) && Date.now() - renderedAt < 1500) {
    return NextResponse.json({ ok: false, error: "too_fast" }, { status: 400 });
  }

  const errors = validateGeneral(data);
  if (hasErrors(errors)) {
    return NextResponse.json({ ok: false, errors }, { status: 422 });
  }

  const { delivered } = await deliverSubmission("general", {
    name: data.name,
    email: data.email,
    message: data.message,
  });

  return NextResponse.json({ ok: true, delivered });
}
