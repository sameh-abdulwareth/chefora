import Image from "next/image";
import type { Metadata } from "next";
import { locales, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/get-dictionary";
import { localizedPath } from "@/i18n/routes";
import { productCategories } from "@/data/products";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { LinkButton } from "@/components/Button";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const dict = await getDictionary(locale as Locale);
  return { title: dict.meta.productsTitle, description: dict.meta.productsDescription };
}

export default async function ProductsPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);

  return (
    <>
      <Section className="pt-12 sm:pt-16">
        <SectionHeading
          align="center"
          eyebrow={dict.products.hero.eyebrow}
          title={dict.products.hero.title}
          subtitle={dict.products.hero.subtitle}
        />
      </Section>

      <Section className="pt-0">
        <div className="space-y-16 sm:space-y-24">
          {productCategories.map((cat, i) => {
            const copy = dict.products.categories.find((c) => c.id === cat.id)!;
            const reversed = i % 2 === 1;
            return (
              <div
                key={cat.id}
                className={`grid items-center gap-10 lg:grid-cols-2 lg:gap-16 ${
                  reversed ? "lg:[&>*:first-child]:order-2" : ""
                }`}
              >
                <div className="relative aspect-[4/3] overflow-hidden rounded-[2rem]">
                  <Image
                    src={cat.image}
                    alt={cat.imageAlt}
                    fill
                    sizes="(min-width: 1024px) 45vw, 90vw"
                    className="object-cover"
                  />
                </div>
                <div>
                  <p className="mb-3 font-display text-3xl font-extrabold text-cocoa/15">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                  <h2 className="font-display text-2xl font-bold text-cocoa sm:text-3xl">
                    {copy.title}
                  </h2>
                  <p className="mt-4 max-w-lg leading-relaxed text-plum/80">{copy.body}</p>
                </div>
              </div>
            );
          })}
        </div>
      </Section>

      <Section className="bg-white/40">
        <p className="mx-auto max-w-2xl text-center text-sm leading-relaxed text-plum/70">
          {dict.products.note}
        </p>
      </Section>

      <Section className="bg-blush/50">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance font-display text-3xl font-bold text-cocoa">
            {dict.products.cta.title}
          </h2>
          <p className="mt-4 text-balance text-lg leading-relaxed text-plum/80">
            {dict.products.cta.body}
          </p>
          <div className="mt-8">
            <LinkButton href={localizedPath(typedLocale, "partnerships")}>
              {dict.products.cta.primary}
            </LinkButton>
          </div>
        </div>
      </Section>
    </>
  );
}
