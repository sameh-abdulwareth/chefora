import type { Metadata } from "next";
import { locales, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/get-dictionary";
import { siteConfig } from "@/data/site";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { ContactTabs } from "@/components/forms/ContactTabs";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const dict = await getDictionary(locale as Locale);
  return { title: dict.meta.contactTitle, description: dict.meta.contactDescription };
}

export default async function ContactPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ type?: string }>;
}) {
  const { locale } = await params;
  const { type } = await searchParams;
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);
  const initialTab = type === "partnership" ? "partnership" : "general";

  const hasDirectInfo = Boolean(siteConfig.contactEmail || siteConfig.contactPhone);

  return (
    <>
      <Section className="pt-12 sm:pt-16">
        <SectionHeading
          align="center"
          eyebrow={dict.contact.hero.eyebrow}
          title={dict.contact.hero.title}
          subtitle={dict.contact.hero.subtitle}
        />
      </Section>

      <Section className="pt-0">
        <div className="mx-auto max-w-2xl">
          <ContactTabs dict={dict} initialTab={initialTab} />

          <div className="mt-8 rounded-2xl border border-cocoa/10 bg-white/40 p-5">
            <p className="text-sm font-semibold text-cocoa">{dict.contact.directInfo.title}</p>
            {hasDirectInfo ? (
              <ul className="mt-2 space-y-1 text-sm text-plum/80">
                {siteConfig.contactEmail && <li>{siteConfig.contactEmail}</li>}
                {siteConfig.contactPhone && <li>{siteConfig.contactPhone}</li>}
              </ul>
            ) : (
              <p className="mt-1 text-sm text-plum/60">{dict.contact.directInfo.note}</p>
            )}
          </div>
        </div>
      </Section>
    </>
  );
}
