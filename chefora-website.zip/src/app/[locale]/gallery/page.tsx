import type { Metadata } from "next";
import { locales, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/get-dictionary";
import { galleryItems } from "@/data/gallery";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { GalleryGrid } from "@/components/GalleryGrid";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const dict = await getDictionary(locale as Locale);
  return { title: dict.meta.galleryTitle, description: dict.meta.galleryDescription };
}

export default async function GalleryPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);

  return (
    <>
      <Section className="pt-12 sm:pt-16">
        <SectionHeading
          align="center"
          eyebrow={dict.gallery.hero.eyebrow}
          title={dict.gallery.hero.title}
          subtitle={dict.gallery.hero.subtitle}
        />
      </Section>

      <Section className="pt-0">
        <GalleryGrid items={galleryItems} locale={typedLocale} dict={dict} />
        <p className="mt-10 text-center text-xs text-plum/50">{dict.gallery.note}</p>
      </Section>
    </>
  );
}
