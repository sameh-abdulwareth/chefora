import Image from "next/image";
import type { Metadata } from "next";
import { locales, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/get-dictionary";
import { localizedPath } from "@/i18n/routes";
import { productCategories } from "@/data/products";
import { galleryItems } from "@/data/gallery";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { LinkButton } from "@/components/Button";
import { FeatureGrid } from "@/components/FeatureCard";
import { ProductCategoryCard } from "@/components/ProductCategoryCard";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const dict = await getDictionary(locale as Locale);
  return { title: dict.meta.homeTitle, description: dict.meta.homeDescription };
}

export default async function HomePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);
  const captionKey = typedLocale;

  return (
    <>
      {/* Hero */}
      <Section className="relative overflow-hidden pt-12 sm:pt-16">
        <div
          aria-hidden
          className="pointer-events-none absolute -end-24 -top-24 h-72 w-72 rounded-full bg-powder/40 blur-2xl"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-16 -start-16 h-64 w-64 rounded-full bg-blush/50 blur-2xl"
        />
        <div className="relative grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="animate-fade-up">
            <p className="mb-4 text-sm font-semibold uppercase tracking-[0.14em] text-cocoa/70">
              {dict.home.hero.eyebrow}
            </p>
            <h1 className="text-balance font-display text-4xl font-extrabold leading-[1.08] text-cocoa sm:text-5xl lg:text-6xl">
              {dict.home.hero.title}
            </h1>
            <p className="mt-6 max-w-xl text-balance text-lg leading-relaxed text-plum/80">
              {dict.home.hero.subtitle}
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <LinkButton href={localizedPath(typedLocale, "products")} variant="primary">
                {dict.home.hero.ctaPrimary}
              </LinkButton>
              <LinkButton href={localizedPath(typedLocale, "partnerships")} variant="secondary">
                {dict.home.hero.ctaSecondary}
              </LinkButton>
            </div>
          </div>

          <div className="animate-fade-up relative" style={{ animationDelay: "120ms" }}>
            <div className="relative mx-auto aspect-square w-full max-w-lg overflow-hidden rounded-[2.5rem] shadow-2xl shadow-cocoa/20 ring-1 ring-cocoa/10">
              <Image
                src="/images/gallery/hero-cookies-banner.jpg"
                alt="CHEFORA cookies, soft serve and chocolate"
                fill
                priority
                sizes="(min-width: 1024px) 32rem, 90vw"
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </Section>

      {/* Intro */}
      <Section className="bg-white/40">
        <SectionHeading
          align="center"
          eyebrow={dict.home.intro.eyebrow}
          title={dict.home.intro.title}
          subtitle={dict.home.intro.body}
        />
      </Section>

      {/* Pillars */}
      <Section>
        <h2 className="sr-only">{dict.home.pillars.title}</h2>
        <FeatureGrid columns={3} items={dict.home.pillars.items} />
      </Section>

      {/* Categories */}
      <Section className="bg-white/40">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
          <SectionHeading eyebrow={dict.home.categories.eyebrow} title={dict.home.categories.title} />
          <LinkButton href={localizedPath(typedLocale, "products")} variant="ghost" className="shrink-0">
            {dict.home.categories.viewAll} →
          </LinkButton>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {productCategories.map((cat, i) => {
            const copy = dict.products.categories.find((c) => c.id === cat.id)!;
            return (
              <ProductCategoryCard
                key={cat.id}
                index={i}
                href={localizedPath(typedLocale, "products")}
                image={cat.image}
                imageAlt={cat.imageAlt}
                title={copy.title}
              />
            );
          })}
        </div>
      </Section>

      {/* Identity in the real world */}
      <Section>
        <SectionHeading
          eyebrow={dict.home.identity.eyebrow}
          title={dict.home.identity.title}
          subtitle={dict.home.identity.body}
          className="mb-10"
        />
        <div className="grid gap-5 sm:grid-cols-3">
          <div className="relative aspect-[3/4] overflow-hidden rounded-3xl sm:col-span-2 sm:aspect-[16/11]">
            <Image
              src="/images/store/storefront-display-case.jpg"
              alt="CHEFORA storefront display case"
              fill
              sizes="(min-width: 640px) 50vw, 100vw"
              className="object-cover"
            />
          </div>
          <div className="grid grid-cols-2 gap-5 sm:grid-cols-1">
            <div className="relative aspect-[4/3] overflow-hidden rounded-3xl sm:aspect-[16/9]">
              <Image
                src="/images/store/vending-kiosk.jpg"
                alt="CHEFORA self-service vending kiosk"
                fill
                sizes="(min-width: 640px) 25vw, 50vw"
                className="object-cover"
              />
            </div>
            <div className="relative aspect-[4/3] overflow-hidden rounded-3xl sm:aspect-[16/9]">
              <Image
                src="/images/people/staff-packing-box.jpg"
                alt="Packing CHEFORA cookies"
                fill
                sizes="(min-width: 640px) 25vw, 50vw"
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </Section>

      {/* Why partner */}
      <Section className="bg-cocoa text-cream">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr] lg:items-start">
          <div>
            <p className="mb-3 text-sm font-semibold uppercase tracking-[0.14em] text-cream/60">
              {dict.home.why.eyebrow}
            </p>
            <h2 className="text-balance font-display text-3xl font-bold sm:text-4xl">
              {dict.home.why.title}
            </h2>
            <LinkButton
              href={localizedPath(typedLocale, "partnerships")}
              variant="secondary"
              className="mt-8 border-cream bg-transparent text-cream hover:bg-cream/10"
            >
              {dict.home.why.cta}
            </LinkButton>
          </div>
          <ul className="grid gap-6 sm:grid-cols-1">
            {dict.home.why.items.map((item, i) => (
              <li key={item.title} className="border-t border-cream/15 pt-6 first:border-t-0 first:pt-0">
                <h3 className="font-display text-lg font-bold">
                  {String(i + 1).padStart(2, "0")} — {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-cream/75">{item.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </Section>

      {/* Gallery preview */}
      <Section>
        <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
          <SectionHeading eyebrow={dict.home.gallery.eyebrow} title={dict.home.gallery.title} />
          <LinkButton href={localizedPath(typedLocale, "gallery")} variant="ghost" className="shrink-0">
            {dict.home.gallery.viewAll} →
          </LinkButton>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {galleryItems.slice(0, 6).map((item, i) => (
            <div
              key={item.id}
              className="animate-fade-up relative aspect-square overflow-hidden rounded-2xl"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <Image
                src={item.src}
                alt={item.caption[captionKey]}
                fill
                sizes="(min-width: 1024px) 16vw, 33vw"
                className="object-cover transition-transform duration-500 hover:scale-105"
              />
            </div>
          ))}
        </div>
      </Section>

      {/* Final CTA */}
      <Section className="bg-blush/50">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance font-display text-3xl font-bold text-cocoa sm:text-4xl">
            {dict.home.finalCta.title}
          </h2>
          <p className="mt-4 text-balance text-lg leading-relaxed text-plum/80">
            {dict.home.finalCta.body}
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <LinkButton href={localizedPath(typedLocale, "contact")} variant="primary">
              {dict.home.finalCta.primary}
            </LinkButton>
            <LinkButton href={localizedPath(typedLocale, "contact")} variant="secondary">
              {dict.home.finalCta.secondary}
            </LinkButton>
          </div>
        </div>
      </Section>
    </>
  );
}
