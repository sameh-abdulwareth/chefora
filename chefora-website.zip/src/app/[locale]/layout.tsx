import type { Metadata, Viewport } from "next";
import { notFound } from "next/navigation";
import { locales, localeDir, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/get-dictionary";
import { siteConfig } from "@/data/site";
import "../fonts";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import "../globals.css";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#faf4eb",
};

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  if (!locales.includes(locale as Locale)) return {};
  const dict = await getDictionary(locale as Locale);

  return {
    metadataBase: new URL(siteConfig.siteUrl),
    title: {
      default: dict.meta.titleSuffix,
      template: `%s · ${siteConfig.brandName}`,
    },
    description: dict.meta.homeDescription,
    alternates: {
      languages: {
        ar: "/ar",
        en: "/en",
      },
    },
    icons: {
      icon: [
        { url: "/images/logos/favicon-32.png", sizes: "32x32", type: "image/png" },
        { url: "/images/logos/favicon-16.png", sizes: "16x16", type: "image/png" },
        { url: "/images/logos/icon-192.png", sizes: "192x192", type: "image/png" },
      ],
      apple: [{ url: "/images/logos/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    },
    openGraph: {
      type: "website",
      siteName: siteConfig.brandName,
      locale: locale === "ar" ? "ar_AR" : "en_US",
      title: dict.meta.titleSuffix,
      description: dict.meta.homeDescription,
      images: [{ url: "/images/gallery/hero-cookies-banner.jpg", width: 1254, height: 1254 }],
    },
    twitter: {
      card: "summary_large_image",
      title: dict.meta.titleSuffix,
      description: dict.meta.homeDescription,
    },
  };
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!locales.includes(locale as Locale)) notFound();
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);

  return (
    <html lang={typedLocale} dir={localeDir[typedLocale]}>
      <body className="flex min-h-screen flex-col font-body antialiased">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-cocoa focus:px-5 focus:py-2.5 focus:text-cream"
        >
          {dict.common.skipToContent}
        </a>
        <Header locale={typedLocale} dict={dict} />
        <main id="main-content" className="flex-1">
          {children}
        </main>
        <Footer locale={typedLocale} dict={dict} />
      </body>
    </html>
  );
}
