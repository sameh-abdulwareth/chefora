import type { Metadata } from "next";
import { locales, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/get-dictionary";
import { Section } from "@/components/Section";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const dict = await getDictionary(locale as Locale);
  return { title: dict.meta.privacyTitle, description: dict.meta.privacyDescription };
}

export default async function PrivacyPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const dict = await getDictionary(locale as Locale);

  return (
    <Section className="pt-12 sm:pt-16">
      <div className="mx-auto max-w-2xl">
        <h1 className="font-display text-3xl font-bold text-cocoa sm:text-4xl">{dict.privacy.title}</h1>
        <p className="mt-2 inline-block rounded-full bg-blush/60 px-3 py-1 text-xs font-semibold text-cocoa">
          {dict.privacy.updated}
        </p>
        <p className="mt-6 leading-relaxed text-plum/80">{dict.privacy.intro}</p>
        <div className="mt-10 space-y-8">
          {dict.privacy.sections.map((section) => (
            <div key={section.title}>
              <h2 className="font-display text-lg font-bold text-cocoa">{section.title}</h2>
              <p className="mt-2 leading-relaxed text-plum/80">{section.body}</p>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
