import Image from "next/image";
import type { Metadata } from "next";
import { locales, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/get-dictionary";
import { localizedPath } from "@/i18n/routes";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { LinkButton } from "@/components/Button";
import { FeatureGrid } from "@/components/FeatureCard";
import { PartnershipForm } from "@/components/forms/PartnershipForm";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const dict = await getDictionary(locale as Locale);
  return { title: dict.meta.partnershipsTitle, description: dict.meta.partnershipsDescription };
}

export default async function PartnershipsPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);

  return (
    <>
      <Section className="relative overflow-hidden pt-12 sm:pt-16">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="animate-fade-up">
            <p className="mb-4 text-sm font-semibold uppercase tracking-[0.14em] text-cocoa/70">
              {dict.partnerships.hero.eyebrow}
            </p>
            <h1 className="text-balance font-display text-4xl font-extrabold leading-[1.1] text-cocoa sm:text-5xl">
              {dict.partnerships.hero.title}
            </h1>
            <p className="mt-6 max-w-xl text-balance text-lg leading-relaxed text-plum/80">
              {dict.partnerships.hero.subtitle}
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <LinkButton href="#partnership-form">{dict.partnerships.hero.ctaPrimary}</LinkButton>
              <LinkButton href={localizedPath(typedLocale, "contact")} variant="secondary">
                {dict.partnerships.hero.ctaSecondary}
              </LinkButton>
            </div>
          </div>
          <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] shadow-2xl shadow-cocoa/20">
            <Image
              src="/images/store/store-opening-ribbon.jpg"
              alt="CHEFORA store opening"
              fill
              priority
              sizes="(min-width: 1024px) 40vw, 90vw"
              className="object-cover"
            />
          </div>
        </div>
      </Section>

      <Section className="bg-white/40">
        <SectionHeading title={dict.partnerships.value.title} className="mb-10" align="center" />
        <FeatureGrid columns={3} items={dict.partnerships.value.items} />
      </Section>

      <Section>
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center lg:gap-16">
          <div className="relative aspect-[4/3] overflow-hidden rounded-[2rem]">
            <Image
              src="/images/store/vending-kiosk.jpg"
              alt="CHEFORA self-service vending kiosk"
              fill
              sizes="(min-width: 1024px) 45vw, 90vw"
              className="object-cover"
            />
          </div>
          <div>
            <p className="mb-3 text-sm font-semibold uppercase tracking-[0.14em] text-cocoa/70">
              {dict.partnerships.experience.eyebrow}
            </p>
            <h2 className="font-display text-2xl font-bold text-cocoa sm:text-3xl">
              {dict.partnerships.experience.title}
            </h2>
            <p className="mt-4 leading-relaxed text-plum/80">{dict.partnerships.experience.body}</p>
            <ul className="mt-6 space-y-3">
              {dict.partnerships.experience.points.map((point) => (
                <li key={point} className="flex gap-3 text-sm leading-relaxed text-plum/80">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-cocoa" />
                  {point}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      <Section className="bg-cocoa text-cream">
        <SectionHeading title={dict.partnerships.process.title} tone="cream" align="center" className="mb-12" />
        <div className="grid gap-8 sm:grid-cols-3">
          {dict.partnerships.process.steps.map((step, i) => (
            <div key={step.title} className="relative">
              <p className="font-display text-4xl font-extrabold text-cream/20">
                {String(i + 1).padStart(2, "0")}
              </p>
              <h3 className="mt-2 font-display text-lg font-bold">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-cream/75">{step.body}</p>
            </div>
          ))}
        </div>
        <p className="mx-auto mt-12 max-w-2xl text-center text-xs leading-relaxed text-cream/55">
          {dict.partnerships.process.disclaimer}
        </p>
      </Section>

      <Section id="partnership-form" className="bg-blush/40">
        <div className="mx-auto max-w-2xl">
          <SectionHeading
            align="center"
            title={dict.partnerships.form.title}
            subtitle={dict.partnerships.form.body}
            className="mb-10"
          />
          <PartnershipForm dict={dict} />
        </div>
      </Section>
    </>
  );
}
