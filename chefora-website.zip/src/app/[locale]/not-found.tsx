import Link from "next/link";

export default function LocaleNotFound() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-5 py-28 text-center">
      <p className="font-display text-6xl font-extrabold text-cocoa/20">404</p>
      <h1 className="mt-4 font-display text-2xl font-bold text-cocoa">
        Page not found · الصفحة غير موجودة
      </h1>
      <p className="mt-3 text-plum/70">
        This page doesn&apos;t exist. · هذه الصفحة غير متوفرة.
      </p>
      <Link
        href="/"
        className="mt-8 inline-flex items-center justify-center rounded-full bg-cocoa px-6 py-3 text-sm font-semibold text-cream"
      >
        Back to home · العودة إلى الرئيسية
      </Link>
    </div>
  );
}
