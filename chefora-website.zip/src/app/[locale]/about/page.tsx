import Image from "next/image";
import type { Metadata } from "next";
import { locales, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/get-dictionary";
import { localizedPath } from "@/i18n/routes";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { LinkButton } from "@/components/Button";
import { FeatureGrid } from "@/components/FeatureCard";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const dict = await getDictionary(locale as Locale);
  return { title: dict.meta.aboutTitle, description: dict.meta.aboutDescription };
}

export default async function AboutPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const typedLocale = locale as Locale;
  const dict = await getDictionary(typedLocale);

  return (
    <>
      <Section className="pt-12 sm:pt-16">
        <SectionHeading
          align="center"
          eyebrow={dict.about.hero.eyebrow}
          title={dict.about.hero.title}
          subtitle={dict.about.hero.subtitle}
        />
      </Section>

      <Section className="bg-white/40">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center lg:gap-16">
          <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem]">
            <Image
              src="/images/people/baker-portrait-pouches.jpg"
              alt="CHEFORA baker with resealable cookie pouches"
              fill
              sizes="(min-width: 1024px) 40vw, 90vw"
              className="object-cover"
            />
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold text-cocoa sm:text-3xl">
              {dict.about.story.title}
            </h2>
            <div className="mt-5 space-y-4">
              {dict.about.story.paragraphs.map((p) => (
                <p key={p} className="leading-relaxed text-plum/80">
                  {p}
                </p>
              ))}
            </div>
          </div>
        </div>
      </Section>

      <Section>
        <SectionHeading title={dict.about.personality.title} className="mb-10" />
        <FeatureGrid items={dict.about.personality.items} columns={4} />
      </Section>

      <Section className="bg-cocoa text-cream">
        <SectionHeading title={dict.about.values.title} tone="cream" className="mb-10" />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {dict.about.values.items.map((item) => (
            <div key={item.title} className="border-s-2 border-cream/30 ps-5">
              <h3 className="font-display text-lg font-bold">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-cream/75">{item.body}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section className="bg-blush/50">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance font-display text-3xl font-bold text-cocoa">
            {dict.about.cta.title}
          </h2>
          <p className="mt-4 text-balance text-lg leading-relaxed text-plum/80">{dict.about.cta.body}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <LinkButton href={localizedPath(typedLocale, "products")}>{dict.about.cta.primary}</LinkButton>
            <LinkButton href={localizedPath(typedLocale, "partnerships")} variant="secondary">
              {dict.about.cta.secondary}
            </LinkButton>
          </div>
        </div>
      </Section>
    </>
  );
}
