import type { MetadataRoute } from "next";
import { locales } from "@/i18n/config";
import { routes } from "@/i18n/routes";
import { siteConfig } from "@/data/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const entries: MetadataRoute.Sitemap = [];

  for (const key of Object.keys(routes) as (keyof typeof routes)[]) {
    for (const locale of locales) {
      const slug = routes[key];
      const path = slug ? `/${locale}/${slug}` : `/${locale}`;
      entries.push({
        url: `${siteConfig.siteUrl}${path}`,
        changeFrequency: key === "home" ? "weekly" : "monthly",
        priority: key === "home" ? 1 : key === "partnerships" ? 0.9 : 0.6,
      });
    }
  }

  return entries;
}
