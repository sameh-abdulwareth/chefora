import Link from "next/link";
import "./globals.css";

export default function RootNotFound() {
  return (
    <html lang="en">
      <body className="flex min-h-screen items-center justify-center bg-cream font-sans">
        <div className="mx-auto flex max-w-md flex-col items-center px-5 py-28 text-center">
          <p className="text-6xl font-extrabold text-[#70361C]/20">404</p>
          <h1 className="mt-4 text-2xl font-bold text-[#70361C]">
            Page not found · الصفحة غير موجودة
          </h1>
          <Link
            href="/ar"
            className="mt-8 inline-flex items-center justify-center rounded-full bg-[#70361C] px-6 py-3 text-sm font-semibold text-[#faf4eb]"
          >
            CHEFORA · شيفورا
          </Link>
        </div>
      </body>
    </html>
  );
}
