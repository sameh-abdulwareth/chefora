"use client";

import { useState } from "react";
import Image from "next/image";
import type { Locale } from "@/i18n/config";
import type { GalleryCategory, GalleryItem } from "@/data/gallery";
import type { Dictionary } from "@/i18n/dictionaries/en";

const categories: GalleryCategory[] = ["store", "packaging", "people", "campaign"];

export function GalleryGrid({
  items,
  locale,
  dict,
}: {
  items: GalleryItem[];
  locale: Locale;
  dict: Dictionary;
}) {
  const [filter, setFilter] = useState<GalleryCategory | "all">("all");
  const [active, setActive] = useState<GalleryItem | null>(null);
  const captionKey = locale;

  const visible = filter === "all" ? items : items.filter((i) => i.category === filter);

  return (
    <div>
      <div className="mb-8 flex flex-wrap gap-2">
        <FilterButton active={filter === "all"} onClick={() => setFilter("all")}>
          {dict.gallery.filters.all}
        </FilterButton>
        {categories.map((cat) => (
          <FilterButton key={cat} active={filter === cat} onClick={() => setFilter(cat)}>
            {dict.gallery.filters[cat]}
          </FilterButton>
        ))}
      </div>

      <div className="columns-2 gap-4 sm:columns-3 lg:columns-4 [&>*]:mb-4">
        {visible.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActive(item)}
            className="group block w-full overflow-hidden rounded-2xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cocoa"
          >
            <div className="relative w-full">
              <Image
                src={item.src}
                alt={item.caption[captionKey]}
                width={800}
                height={1000}
                sizes="(min-width: 1024px) 24vw, (min-width: 640px) 33vw, 50vw"
                className="w-full rounded-2xl object-cover transition-transform duration-500 group-hover:scale-[1.03]"
              />
            </div>
          </button>
        ))}
      </div>

      {active && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={active.caption[captionKey]}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-cocoa/90 p-4 sm:p-8"
          onClick={() => setActive(null)}
        >
          <button
            type="button"
            onClick={() => setActive(null)}
            aria-label={dict.nav.close}
            className="absolute end-4 top-4 rounded-full bg-cream/90 p-2.5 text-cocoa sm:end-8 sm:top-8"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M6 6L18 18M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
          <div className="relative max-h-[85vh] max-w-3xl" onClick={(e) => e.stopPropagation()}>
            <Image
              src={active.src}
              alt={active.caption[captionKey]}
              width={1200}
              height={1500}
              className="max-h-[85vh] w-auto rounded-2xl object-contain"
            />
            <p className="mt-3 text-center text-sm font-medium text-cream">{active.caption[captionKey]}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function FilterButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
        active ? "bg-cocoa text-cream" : "bg-white/60 text-cocoa/70 hover:bg-white"
      }`}
    >
      {children}
    </button>
  );
}
