const palette = [
  { bg: "bg-blush", text: "text-cocoa", sub: "text-cocoa/70" },
  { bg: "bg-powder", text: "text-plum", sub: "text-plum/70" },
  { bg: "bg-cocoa", text: "text-cream", sub: "text-cream/75" },
  { bg: "bg-cream border-2 border-cocoa/15", text: "text-cocoa", sub: "text-cocoa/70" },
];

export function FeatureGrid({
  items,
  columns = 4,
}: {
  items: { title: string; body: string }[];
  columns?: 3 | 4;
}) {
  const colsClass = columns === 3 ? "lg:grid-cols-3" : "lg:grid-cols-4";
  return (
    <div className={`grid gap-5 sm:grid-cols-2 ${colsClass}`}>
      {items.map((item, i) => {
        const style = palette[i % palette.length];
        return (
          <div
            key={item.title}
            className={`animate-fade-up rounded-3xl p-6 sm:p-7 ${style.bg}`}
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <p className={`mb-2 font-display text-lg font-bold ${style.text}`}>
              {String(i + 1).padStart(2, "0")}
            </p>
            <h3 className={`font-display text-xl font-bold ${style.text}`}>{item.title}</h3>
            <p className={`mt-2 text-sm leading-relaxed ${style.sub}`}>{item.body}</p>
          </div>
        );
      })}
    </div>
  );
}
