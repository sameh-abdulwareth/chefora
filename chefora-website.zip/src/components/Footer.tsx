import Image from "next/image";
import Link from "next/link";
import type { Locale } from "@/i18n/config";
import { localizedPath, type NavRouteKey } from "@/i18n/routes";
import type { Dictionary } from "@/i18n/dictionaries/en";
import { Container } from "./Container";

const exploreLinks: NavRouteKey[] = ["products", "gallery"];
const companyLinks: NavRouteKey[] = ["about", "partnerships", "contact"];

export function Footer({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-cream/10 bg-cocoa text-cream">
      <Container className="py-14">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <Image
              src="/images/logos/chefora-wordmark-white.png"
              alt="CHEFORA"
              width={1953}
              height={1093}
              className="h-8 w-auto"
            />
            <p className="mt-4 max-w-[22ch] text-sm text-cream/70">{dict.footer.tagline}</p>
          </div>

          <FooterColumn title={dict.footer.columns.explore} keys={exploreLinks} locale={locale} dict={dict} />
          <FooterColumn title={dict.footer.columns.company} keys={companyLinks} locale={locale} dict={dict} />

          <div>
            <p className="text-sm font-semibold uppercase tracking-wide text-cream/50">
              {dict.footer.columns.legal}
            </p>
            <ul className="mt-4 space-y-3">
              <li>
                <Link href={localizedPath(locale, "privacy")} className="text-sm text-cream/80 hover:text-cream">
                  {dict.footer.privacy}
                </Link>
              </li>
              <li>
                <Link href={localizedPath(locale, "terms")} className="text-sm text-cream/80 hover:text-cream">
                  {dict.footer.terms}
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-cream/10 pt-6 text-xs text-cream/50 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} CHEFORA. {dict.footer.rights}
          </p>
          <p>{dict.footer.madeFor}</p>
        </div>
      </Container>
    </footer>
  );
}

function FooterColumn({
  title,
  keys,
  locale,
  dict,
}: {
  title: string;
  keys: NavRouteKey[];
  locale: Locale;
  dict: Dictionary;
}) {
  return (
    <div>
      <p className="text-sm font-semibold uppercase tracking-wide text-cream/50">{title}</p>
      <ul className="mt-4 space-y-3">
        {keys.map((key) => (
          <li key={key}>
            <Link href={localizedPath(locale, key)} className="text-sm text-cream/80 hover:text-cream">
              {dict.nav[key]}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
