import Image from "next/image";
import Link from "next/link";

export function ProductCategoryCard({
  href,
  image,
  imageAlt,
  title,
  body,
  index = 0,
}: {
  href: string;
  image: string;
  imageAlt: string;
  title: string;
  body?: string;
  index?: number;
}) {
  return (
    <Link
      href={href}
      className="group animate-fade-up block overflow-hidden rounded-3xl bg-white/40 ring-1 ring-cocoa/10 transition-shadow hover:shadow-lg hover:shadow-cocoa/10"
      style={{ animationDelay: `${index * 90}ms` }}
    >
      <div className="relative aspect-[4/5] w-full overflow-hidden">
        <Image
          src={image}
          alt={imageAlt}
          fill
          sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-cocoa/70 via-cocoa/0 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-5">
          <h3 className="font-display text-xl font-bold text-cream">{title}</h3>
        </div>
      </div>
      {body && (
        <p className="p-5 text-sm leading-relaxed text-plum/75">{body}</p>
      )}
    </Link>
  );
}
