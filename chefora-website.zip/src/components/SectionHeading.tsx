export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "start",
  tone = "cocoa",
  className = "",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: "start" | "center";
  tone?: "cocoa" | "cream";
  className?: string;
}) {
  const titleColor = tone === "cream" ? "text-cream" : "text-cocoa";
  const eyebrowColor = tone === "cream" ? "text-cream/60" : "text-cocoa/70";
  const subtitleColor = tone === "cream" ? "text-cream/75" : "text-plum/80";

  return (
    <div
      className={`max-w-3xl ${align === "center" ? "mx-auto text-center" : ""} ${className}`}
    >
      {eyebrow && (
        <p className={`mb-3 text-sm font-semibold uppercase tracking-[0.14em] ${eyebrowColor}`}>
          {eyebrow}
        </p>
      )}
      <h2 className={`font-display text-3xl font-bold text-balance sm:text-4xl ${titleColor}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-4 text-balance text-lg leading-relaxed ${subtitleColor}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
}
