"use client";

import { useState } from "react";
import type { Dictionary } from "@/i18n/dictionaries/en";
import { GeneralForm } from "./GeneralForm";
import { PartnershipForm } from "./PartnershipForm";

export function ContactTabs({
  dict,
  initialTab,
}: {
  dict: Dictionary;
  initialTab: "general" | "partnership";
}) {
  const [tab, setTab] = useState<"general" | "partnership">(initialTab);

  return (
    <div>
      <div role="tablist" aria-label="Contact form type" className="mb-8 inline-flex rounded-full bg-white/60 p-1">
        <button
          role="tab"
          type="button"
          aria-selected={tab === "general"}
          onClick={() => setTab("general")}
          className={`rounded-full px-5 py-2.5 text-sm font-semibold transition-colors ${
            tab === "general" ? "bg-cocoa text-cream" : "text-cocoa/70"
          }`}
        >
          {dict.contact.tabs.general}
        </button>
        <button
          role="tab"
          type="button"
          aria-selected={tab === "partnership"}
          onClick={() => setTab("partnership")}
          className={`rounded-full px-5 py-2.5 text-sm font-semibold transition-colors ${
            tab === "partnership" ? "bg-cocoa text-cream" : "text-cocoa/70"
          }`}
        >
          {dict.contact.tabs.partnership}
        </button>
      </div>

      {tab === "general" ? (
        <div>
          <p className="mb-5 text-sm leading-relaxed text-plum/70">{dict.contact.generalForm.body}</p>
          <GeneralForm dict={dict} />
        </div>
      ) : (
        <div>
          <p className="mb-5 text-sm leading-relaxed text-plum/70">{dict.contact.partnershipForm.body}</p>
          <PartnershipForm dict={dict} />
        </div>
      )}
    </div>
  );
}
