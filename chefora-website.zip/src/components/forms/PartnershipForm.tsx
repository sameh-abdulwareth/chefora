"use client";

import { useState } from "react";
import type { Dictionary } from "@/i18n/dictionaries/en";
import { validatePartnership, hasErrors, type PartnershipFormData } from "@/lib/validation";
import { Field, TextInput, TextArea, Select } from "./fields";
import { Button } from "../Button";

type Status = "idle" | "submitting" | "success" | "error";

const emptyData: PartnershipFormData = {
  companyName: "",
  contactName: "",
  email: "",
  phone: "",
  country: "",
  city: "",
  interest: "",
  companyBrief: "",
  message: "",
  company_website: "",
  renderedAt: "",
};

export function PartnershipForm({ dict }: { dict: Dictionary }) {
  const f = dict.contact.fields;
  const [data, setData] = useState<PartnershipFormData>(emptyData);
  const [errors, setErrors] = useState<Partial<Record<keyof PartnershipFormData, string>>>({});
  const [status, setStatus] = useState<Status>("idle");
  const [renderedAt] = useState(() => Date.now().toString());

  function update<K extends keyof PartnershipFormData>(key: K, value: PartnershipFormData[K]) {
    setData((d) => ({ ...d, [key]: value }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const payload = { ...data, renderedAt };
    const clientErrors = validatePartnership(payload);
    setErrors(clientErrors);
    if (hasErrors(clientErrors)) return;

    setStatus("submitting");
    try {
      const res = await fetch("/api/partnership", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("request_failed");
      setStatus("success");
      setData(emptyData);
    } catch {
      setStatus("error");
    }
  }

  function errorText(key: keyof PartnershipFormData) {
    const code = errors[key];
    if (!code) return undefined;
    if (code === "email") return f.errors.email;
    if (code === "minLength") return f.errors.minLength;
    return f.errors.required;
  }

  if (status === "success") {
    return (
      <div role="status" className="rounded-2xl bg-white/70 p-8 text-center">
        <p className="font-display text-lg font-bold text-cocoa">{dict.contact.success.partnership}</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5 rounded-3xl bg-white/70 p-6 sm:p-8">
      {/* Honeypot field — hidden from real users, visible to bots */}
      <div className="hidden" aria-hidden="true">
        <label htmlFor="company_website">Company website</label>
        <input
          id="company_website"
          name="company_website"
          type="text"
          tabIndex={-1}
          autoComplete="off"
          value={data.company_website}
          onChange={(e) => update("company_website", e.target.value)}
        />
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={f.companyName} htmlFor="companyName" required error={errorText("companyName")}>
          <TextInput
            id="companyName"
            name="companyName"
            required
            invalid={!!errors.companyName}
            placeholder={f.placeholders.companyName}
            value={data.companyName}
            onChange={(e) => update("companyName", e.target.value)}
          />
        </Field>
        <Field label={f.contactName} htmlFor="contactName" required error={errorText("contactName")}>
          <TextInput
            id="contactName"
            name="contactName"
            required
            invalid={!!errors.contactName}
            placeholder={f.placeholders.contactName}
            value={data.contactName}
            onChange={(e) => update("contactName", e.target.value)}
          />
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={f.email} htmlFor="email" required error={errorText("email")}>
          <TextInput
            id="email"
            name="email"
            type="email"
            required
            invalid={!!errors.email}
            placeholder={f.placeholders.email}
            value={data.email}
            onChange={(e) => update("email", e.target.value)}
          />
        </Field>
        <Field label={f.phone} htmlFor="phone" error={errorText("phone")}>
          <TextInput
            id="phone"
            name="phone"
            type="tel"
            placeholder={f.placeholders.phone}
            value={data.phone}
            onChange={(e) => update("phone", e.target.value)}
          />
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={f.country} htmlFor="country" required error={errorText("country")}>
          <TextInput
            id="country"
            name="country"
            required
            invalid={!!errors.country}
            placeholder={f.placeholders.country}
            value={data.country}
            onChange={(e) => update("country", e.target.value)}
          />
        </Field>
        <Field label={f.city} htmlFor="city" error={errorText("city")}>
          <TextInput
            id="city"
            name="city"
            placeholder={f.placeholders.city}
            value={data.city}
            onChange={(e) => update("city", e.target.value)}
          />
        </Field>
      </div>

      <Field label={f.interest} htmlFor="interest" required error={errorText("interest")}>
        <Select
          id="interest"
          name="interest"
          required
          invalid={!!errors.interest}
          value={data.interest}
          onChange={(e) => update("interest", e.target.value as PartnershipFormData["interest"])}
        >
          <option value="" disabled>
            {f.interest}
          </option>
          <option value="agency">{f.interestOptions.agency}</option>
          <option value="distribution">{f.interestOptions.distribution}</option>
          <option value="other">{f.interestOptions.other}</option>
        </Select>
      </Field>

      <Field label={f.companyBrief} htmlFor="companyBrief" required error={errorText("companyBrief")}>
        <TextArea
          id="companyBrief"
          name="companyBrief"
          required
          invalid={!!errors.companyBrief}
          placeholder={f.placeholders.companyBrief}
          value={data.companyBrief}
          onChange={(e) => update("companyBrief", e.target.value)}
        />
      </Field>

      <Field label={f.message} htmlFor="message" error={errorText("message")}>
        <TextArea
          id="message"
          name="message"
          placeholder={f.placeholders.partnershipMessage}
          value={data.message}
          onChange={(e) => update("message", e.target.value)}
        />
      </Field>

      {status === "error" && (
        <p role="alert" className="text-sm font-medium text-red-700">
          {dict.contact.error}
        </p>
      )}

      <Button type="submit" disabled={status === "submitting"} className="w-full sm:w-auto">
        {status === "submitting" ? f.submitting : f.submit}
      </Button>
    </form>
  );
}
