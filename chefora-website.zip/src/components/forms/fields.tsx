import type { ReactNode } from "react";

const inputBase =
  "w-full rounded-xl border border-cocoa/20 bg-white/70 px-4 py-3 text-sm text-plum placeholder:text-plum/40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cocoa";

export function Field({
  label,
  htmlFor,
  error,
  children,
  required,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  children: ReactNode;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-semibold text-cocoa">
        {label} {required && <span aria-hidden="true">*</span>}
      </label>
      {children}
      {error && (
        <p role="alert" className="mt-1.5 text-xs font-medium text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}

export function TextInput(
  props: React.InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }
) {
  const { invalid, className = "", ...rest } = props;
  return (
    <input
      className={`${inputBase} ${invalid ? "border-red-400" : ""} ${className}`}
      aria-invalid={invalid || undefined}
      {...rest}
    />
  );
}

export function TextArea(
  props: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }
) {
  const { invalid, className = "", ...rest } = props;
  return (
    <textarea
      className={`${inputBase} min-h-[120px] resize-y ${invalid ? "border-red-400" : ""} ${className}`}
      aria-invalid={invalid || undefined}
      {...rest}
    />
  );
}

export function Select(
  props: React.SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean }
) {
  const { invalid, className = "", children, ...rest } = props;
  return (
    <select
      className={`${inputBase} ${invalid ? "border-red-400" : ""} ${className}`}
      aria-invalid={invalid || undefined}
      {...rest}
    >
      {children}
    </select>
  );
}
