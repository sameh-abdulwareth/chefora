"use client";

import { useState } from "react";
import type { Dictionary } from "@/i18n/dictionaries/en";
import { validateGeneral, hasErrors, type GeneralFormData } from "@/lib/validation";
import { Field, TextInput, TextArea } from "./fields";
import { Button } from "../Button";

type Status = "idle" | "submitting" | "success" | "error";

const emptyData: GeneralFormData = {
  name: "",
  email: "",
  message: "",
  company_website: "",
  renderedAt: "",
};

export function GeneralForm({ dict }: { dict: Dictionary }) {
  const f = dict.contact.fields;
  const [data, setData] = useState<GeneralFormData>(emptyData);
  const [errors, setErrors] = useState<Partial<Record<keyof GeneralFormData, string>>>({});
  const [status, setStatus] = useState<Status>("idle");
  const [renderedAt] = useState(() => Date.now().toString());

  function update<K extends keyof GeneralFormData>(key: K, value: GeneralFormData[K]) {
    setData((d) => ({ ...d, [key]: value }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const payload = { ...data, renderedAt };
    const clientErrors = validateGeneral(payload);
    setErrors(clientErrors);
    if (hasErrors(clientErrors)) return;

    setStatus("submitting");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("request_failed");
      setStatus("success");
      setData(emptyData);
    } catch {
      setStatus("error");
    }
  }

  function errorText(key: keyof GeneralFormData) {
    const code = errors[key];
    if (!code) return undefined;
    if (code === "email") return f.errors.email;
    if (code === "minLength") return f.errors.minLength;
    return f.errors.required;
  }

  if (status === "success") {
    return (
      <div role="status" className="rounded-2xl bg-white/70 p-8 text-center">
        <p className="font-display text-lg font-bold text-cocoa">{dict.contact.success.general}</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5 rounded-3xl bg-white/70 p-6 sm:p-8">
      <div className="hidden" aria-hidden="true">
        <label htmlFor="gf_company_website">Company website</label>
        <input
          id="gf_company_website"
          name="company_website"
          type="text"
          tabIndex={-1}
          autoComplete="off"
          value={data.company_website}
          onChange={(e) => update("company_website", e.target.value)}
        />
      </div>

      <Field label={f.name} htmlFor="gf_name" required error={errorText("name")}>
        <TextInput
          id="gf_name"
          name="name"
          required
          invalid={!!errors.name}
          placeholder={f.placeholders.name}
          value={data.name}
          onChange={(e) => update("name", e.target.value)}
        />
      </Field>

      <Field label={f.email} htmlFor="gf_email" required error={errorText("email")}>
        <TextInput
          id="gf_email"
          name="email"
          type="email"
          required
          invalid={!!errors.email}
          placeholder={f.placeholders.email}
          value={data.email}
          onChange={(e) => update("email", e.target.value)}
        />
      </Field>

      <Field label={f.message} htmlFor="gf_message" required error={errorText("message")}>
        <TextArea
          id="gf_message"
          name="message"
          required
          invalid={!!errors.message}
          placeholder={f.placeholders.message}
          value={data.message}
          onChange={(e) => update("message", e.target.value)}
        />
      </Field>

      {status === "error" && (
        <p role="alert" className="text-sm font-medium text-red-700">
          {dict.contact.error}
        </p>
      )}

      <Button type="submit" disabled={status === "submitting"} className="w-full sm:w-auto">
        {status === "submitting" ? f.submitting : f.submit}
      </Button>
    </form>
  );
}
