import Image from "next/image";
import Link from "next/link";
import type { Locale } from "@/i18n/config";
import { localizedPath } from "@/i18n/routes";

export function Logo({
  locale,
  variant = "cocoa",
  className = "",
  priority = false,
}: {
  locale: Locale;
  variant?: "cocoa" | "white";
  className?: string;
  priority?: boolean;
}) {
  const src =
    variant === "white"
      ? "/images/logos/chefora-wordmark-white.png"
      : "/images/logos/chefora-wordmark-cocoa.png";

  return (
    <Link
      href={localizedPath(locale, "home")}
      aria-label="CHEFORA — home"
      className={`inline-flex items-center ${className}`}
    >
      <Image
        src={src}
        alt="CHEFORA"
        width={1953}
        height={1093}
        priority={priority}
        className="h-8 w-auto sm:h-9"
      />
    </Link>
  );
}
