"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { Locale } from "@/i18n/config";
import { switchToLabel } from "@/i18n/config";
import { localizedPath, routes, type NavRouteKey } from "@/i18n/routes";
import { Logo } from "./Logo";
import type { Dictionary } from "@/i18n/dictionaries/en";

const navItems: NavRouteKey[] = ["home", "about", "products", "partnerships", "gallery"];

export function Header({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  const otherLocale: Locale = locale === "ar" ? "en" : "ar";
  const otherHref = swapLocaleInPath(pathname, otherLocale);

  return (
    <header className="sticky top-0 z-50 border-b border-cocoa/10 bg-cream/90 backdrop-blur">
      <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-4 px-5 py-3 sm:px-8">
        <Logo locale={locale} priority />

        <nav className="hidden items-center gap-7 lg:flex">
          {navItems.map((key) => {
            const href = localizedPath(locale, key);
            const active = isActive(pathname, href);
            return (
              <Link
                key={key}
                href={href}
                className={`text-sm font-semibold transition-colors ${
                  active ? "text-cocoa" : "text-cocoa/60 hover:text-cocoa"
                }`}
                aria-current={active ? "page" : undefined}
              >
                {dict.nav[key]}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Link
            href={otherHref}
            className="rounded-full border border-cocoa/25 px-3.5 py-1.5 text-sm font-semibold text-cocoa/80 transition-colors hover:border-cocoa hover:text-cocoa"
            aria-label={`Switch to ${switchToLabel[locale]}`}
          >
            {switchToLabel[locale]}
          </Link>
          <Link
            href={localizedPath(locale, "contact")}
            className="rounded-full bg-cocoa px-5 py-2.5 text-sm font-semibold text-cream transition-colors hover:bg-cocoa-dark"
          >
            {dict.nav.cta}
          </Link>
        </div>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="inline-flex items-center justify-center rounded-full border border-cocoa/20 p-2.5 text-cocoa lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? dict.nav.close : dict.nav.menu}
        >
          <MenuIcon open={open} />
        </button>
      </div>

      {open && (
        <div id="mobile-menu" className="border-t border-cocoa/10 bg-cream lg:hidden">
          <nav className="flex flex-col gap-1 px-5 py-4">
            {navItems.map((key) => {
              const href = localizedPath(locale, key);
              const active = isActive(pathname, href);
              return (
                <Link
                  key={key}
                  href={href}
                  onClick={() => setOpen(false)}
                  className={`rounded-lg px-3 py-2.5 text-base font-semibold ${
                    active ? "bg-blush/50 text-cocoa" : "text-cocoa/80"
                  }`}
                  aria-current={active ? "page" : undefined}
                >
                  {dict.nav[key]}
                </Link>
              );
            })}
            <Link
              href={localizedPath(locale, "contact")}
              onClick={() => setOpen(false)}
              className="mt-2 rounded-lg px-3 py-2.5 text-base font-semibold text-cocoa/80"
            >
              {dict.nav.contact}
            </Link>
            <div className="mt-3 flex items-center gap-3 border-t border-cocoa/10 pt-4">
              <Link
                href={otherHref}
                onClick={() => setOpen(false)}
                className="rounded-full border border-cocoa/25 px-4 py-2 text-sm font-semibold text-cocoa"
              >
                {switchToLabel[locale]}
              </Link>
              <Link
                href={localizedPath(locale, "contact")}
                onClick={() => setOpen(false)}
                className="rounded-full bg-cocoa px-5 py-2.5 text-sm font-semibold text-cream"
              >
                {dict.nav.cta}
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}

function isActive(pathname: string, href: string) {
  if (href.endsWith(`/${routes.home}`) || href.split("/").length === 2) {
    return pathname === href;
  }
  return pathname === href || pathname.startsWith(`${href}/`);
}

function swapLocaleInPath(pathname: string, target: Locale) {
  const parts = pathname.split("/");
  parts[1] = target;
  return parts.join("/") || `/${target}`;
}

function MenuIcon({ open }: { open: boolean }) {
  if (open) {
    return (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M6 6L18 18M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 7H20M4 12H20M4 17H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
