import type { Locale } from "./config";

// Route slugs are kept identical across locales (Latin, URL-safe) so the
// language switcher can swap only the locale segment and land on the same page.
export const routes = {
  home: "",
  about: "about",
  products: "products",
  partnerships: "partnerships",
  gallery: "gallery",
  contact: "contact",
  privacy: "privacy",
  terms: "terms",
} as const;

export type RouteKey = keyof typeof routes;

// Route keys that also exist under dict.nav (i.e. everything except the
// legal pages, which are only linked from the footer via dict.footer).
export type NavRouteKey = Exclude<RouteKey, "privacy" | "terms">;

export function localizedPath(locale: Locale, key: RouteKey): string {
  const slug = routes[key];
  return slug ? `/${locale}/${slug}` : `/${locale}`;
}
