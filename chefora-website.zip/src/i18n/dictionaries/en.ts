const en = {
  meta: {
    siteName: "CHEFORA",
    titleSuffix: "CHEFORA | Sweets with a little more joy",
    homeTitle: "CHEFORA — Cookies, Pastries & Chocolate, Made for Sharing",
    homeDescription:
      "CHEFORA is a modern confectionery brand built around cookies, pastries, chocolate and playful frozen treats. Explore the brand and start a partnership conversation.",
    aboutTitle: "About CHEFORA — Our Story & Personality",
    aboutDescription:
      "Discover the CHEFORA brand: a warm, playful and confident identity built for cookies, pastries, chocolate and joyful everyday treats.",
    productsTitle: "Products — Cookies, Pastries, Chocolate & More",
    productsDescription:
      "A look at the CHEFORA product world: fresh-baked cookies, croissants and pastries, chocolate, and bubble waffle & ice cream treats.",
    partnershipsTitle: "Partnerships & Agencies — Bring CHEFORA to Your Market",
    partnershipsDescription:
      "Explore a distribution or agency partnership with CHEFORA. A distinctive identity, real retail formats and a product-first experience.",
    galleryTitle: "Gallery — Stores, Packaging & Campaigns",
    galleryDescription:
      "A curated look at CHEFORA's stores, packaging, team and campaign photography.",
    contactTitle: "Contact CHEFORA",
    contactDescription:
      "Get in touch with CHEFORA for general questions or to start a partnership request.",
    privacyTitle: "Privacy Policy",
    privacyDescription: "How CHEFORA handles the information you share with us.",
    termsTitle: "Terms of Use",
    termsDescription: "The terms that govern use of the CHEFORA website.",
  },

  nav: {
    home: "Home",
    about: "About",
    products: "Products",
    partnerships: "Partnerships",
    gallery: "Gallery",
    contact: "Contact",
    cta: "Request a Partnership Deck",
    menu: "Menu",
    close: "Close",
  },

  footer: {
    tagline: "Sweets with a little more joy.",
    columns: {
      explore: "Explore",
      company: "Company",
      legal: "Legal",
    },
    privacy: "Privacy Policy",
    terms: "Terms of Use",
    rights: "All rights reserved.",
    madeFor: "A brand identity presentation built for partnership review.",
  },

  home: {
    hero: {
      eyebrow: "CHEFORA · Brand System 2026",
      title: "Sweets with a little more joy",
      subtitle:
        "CHEFORA brings warm, generous indulgence to cookies, pastries, chocolate and playful frozen treats — with a look built to be unmistakable on every shelf, counter and storefront.",
      ctaPrimary: "Explore Products",
      ctaSecondary: "Explore Partnership",
    },
    intro: {
      eyebrow: "The Brand",
      title: "Joy in every bite.",
      body: "CHEFORA creates generous, feel-good moments around cookies, pastries, chocolate and everyday gifting. The visual language is warm, playful and confident — designed to read clearly from a shelf, a storefront sign or a phone screen alike.",
    },
    pillars: {
      title: "Brand character",
      items: [
        {
          title: "Playful",
          body: "Soft bite shapes and cheerful details carried through packaging, uniforms and retail spaces.",
        },
        {
          title: "Appetizing",
          body: "Real texture, warm light and visible product — the food is always the hero.",
        },
        {
          title: "Confident",
          body: "A clear wordmark with generous spacing, built to hold its own next to any brand on the shelf.",
        },
      ],
    },
    categories: {
      eyebrow: "What we make",
      title: "A product world built for variety",
      viewAll: "View all products",
    },
    identity: {
      eyebrow: "Identity in the real world",
      title: "One identity, consistent everywhere",
      body: "From packaging and uniforms to storefronts and self-service kiosks, the CHEFORA identity is designed to travel across every format a partner needs — always led by the product itself.",
    },
    why: {
      eyebrow: "For partners",
      title: "Why brands and operators choose to work with CHEFORA",
      items: [
        {
          title: "A distinctive, flexible identity",
          body: "A rounded, high-contrast wordmark and a warm color system that stays recognizable across signage, packaging, apparel and digital.",
        },
        {
          title: "Retail formats that already work",
          body: "From a full storefront experience to a compact self-service vending kiosk, the brand has been designed across multiple real-world formats.",
        },
        {
          title: "Product-first photography and packaging",
          body: "Every touchpoint — from resealable pouches to takeaway trays — is built to keep the food looking generous and appetizing.",
        },
      ],
      cta: "Explore the partnership page",
    },
    gallery: {
      eyebrow: "A closer look",
      title: "Stores, packaging and people",
      viewAll: "View full gallery",
    },
    finalCta: {
      title: "Let's talk about bringing CHEFORA to your market",
      body: "Whether you're exploring an agency, distribution or another kind of commercial partnership, we'd like to hear from you.",
      primary: "Request a Partnership Deck",
      secondary: "Contact Us",
    },
  },

  about: {
    hero: {
      eyebrow: "About CHEFORA",
      title: "A little more joy in every bite",
      subtitle:
        "CHEFORA is a confectionery brand built around cookies, pastries, chocolate and playful frozen treats — designed to feel warm, generous and unmistakably itself at every touchpoint.",
    },
    story: {
      title: "A brand built around the product",
      paragraphs: [
        "CHEFORA exists to create generous, feel-good moments around everyday treats — fresh-baked cookies, croissants and pastries, chocolate, and playful bubble waffle and ice cream combinations.",
        "The identity is deliberately warm rather than loud: a soft, rounded wordmark with a signature bite detail on the C and F, a confident cocoa-and-cream palette, and gentle accent colors that let the food stay the visual hero.",
        "Every touchpoint — from the packaging in a customer's hand to the uniform behind the counter — is designed to carry the same character, so CHEFORA feels consistent whether it's a full storefront, a self-service kiosk, or a resealable pouch on a retail shelf.",
      ],
    },
    personality: {
      title: "Brand personality",
      items: [
        { title: "Friendly", body: "Warm without trying too hard — the kind of brand people want to bring home." },
        { title: "Modern", body: "A clean, confident visual system that holds up across packaging, retail and digital." },
        { title: "Generous", body: "Portions, packaging and imagery that always feel like a little more joy, not less." },
        { title: "Indulgent", body: "Real texture and warm light keep the product looking as good as it tastes." },
      ],
    },
    values: {
      title: "How the identity is used",
      items: [
        { title: "Signage", body: "Large, high-contrast lettering that keeps storefronts calm and legible." },
        { title: "Packaging", body: "One clear logo placement per piece, always protecting the food photography." },
        { title: "Uniforms", body: "A powder blue or blush apron with the wordmark printed in cocoa." },
        { title: "Photography", body: "Realistic faces, hands and food texture, shot in warm, natural light." },
      ],
    },
    cta: {
      title: "Curious how CHEFORA could work in your market?",
      body: "Take a look at the products and the partnership opportunity, or reach out directly.",
      primary: "View Products",
      secondary: "Explore Partnership",
    },
  },

  products: {
    hero: {
      eyebrow: "Products",
      title: "A product world built for variety",
      subtitle:
        "From fresh-baked cookies to playful frozen treats, every CHEFORA category is designed to look generous, real and instantly appetizing.",
    },
    categories: [
      {
        id: "cookies",
        title: "Cookies",
        body: "Thick, generously loaded cookies finished with visible chocolate and a soft, gooey center — sold fresh from the counter or packed into resealable pouches to take home.",
      },
      {
        id: "pastries",
        title: "Croissants & Baked Pastries",
        body: "A daily case of croissants, cinnamon rolls and glazed pastries, displayed warm and close to the counter so the product does the selling.",
      },
      {
        id: "chocolate",
        title: "Chocolate",
        body: "Generous chocolate pieces and drizzle appear across the range — from cookie fillings to indulgent chocolate drinks — as a signature texture of the brand.",
      },
      {
        id: "frozen",
        title: "Bubble Waffle & Ice Cream",
        body: "Warm bubble waffles piled high with soft serve, sauces and toppings — a shareable, photo-ready treat built for the counter and for takeaway.",
      },
    ],
    note: "Product availability can vary by location and format. This page reflects the categories represented in CHEFORA's current brand and product photography.",
    cta: {
      title: "Interested in carrying the full CHEFORA range?",
      body: "Partners get access to the complete product and packaging system.",
      primary: "Explore Partnership",
    },
  },

  partnerships: {
    hero: {
      eyebrow: "For Companies & Operators",
      title: "Bring CHEFORA to your market",
      subtitle:
        "We're exploring agency, distribution and other commercial partnerships with companies who share the same standard for product quality and brand presentation.",
      ctaPrimary: "Request a Partnership Deck",
      ctaSecondary: "Contact Us",
    },
    value: {
      title: "What makes CHEFORA worth partnering with",
      items: [
        {
          title: "A complete, ready-to-apply identity",
          body: "Wordmark, color system, packaging language, uniforms and store direction are already defined and documented in a full brand system — not a logo alone.",
        },
        {
          title: "Real retail formats",
          body: "The brand has been designed across a full storefront experience, a compact self-service vending kiosk, and takeaway packaging — giving partners flexibility in how they bring it to market.",
        },
        {
          title: "A product-first, shareable experience",
          body: "Generous portions, visible texture and playful presentation are built to perform well in-store and on social — from a simple cookie pouch to an oversized bubble waffle moment.",
        },
      ],
    },
    experience: {
      eyebrow: "What partners get",
      title: "Identity, product and store experience — together",
      body: "A CHEFORA partnership isn't just a name to license. It comes with a documented visual identity, real packaging and uniform direction, and a retail format that has already been thought through — from counter service to self-service.",
      points: [
        "A documented brand identity: logo usage, color palette, typography direction and photography style.",
        "Packaging and retail materials designed around the product, not around the logo.",
        "Flexible formats — from a full café-style storefront to a compact vending kiosk.",
        "A visual world built to travel across signage, apparel, packaging and digital.",
      ],
    },
    process: {
      title: "How to start the conversation",
      steps: [
        {
          title: "Tell us about your company",
          body: "Share a short brief about your business, your market and the type of partnership you're exploring.",
        },
        {
          title: "We review together",
          body: "Our team reviews your request and follows up to understand fit, market and next steps.",
        },
        {
          title: "We talk specifics",
          body: "If there's a fit, we discuss terms, territory and next steps directly — nothing is assumed in advance.",
        },
      ],
      disclaimer:
        "Agency and distribution rights are not confirmed for any specific country by this page. Territory availability, terms and requirements are discussed directly with each applicant.",
    },
    form: {
      title: "Request a partnership deck",
      body: "Fill in a few details about your company and we'll be in touch about a CHEFORA partnership.",
    },
  },

  gallery: {
    hero: {
      eyebrow: "Gallery",
      title: "Stores, packaging and campaigns",
      subtitle:
        "A curated look at how the CHEFORA identity shows up in real spaces — from the storefront and packaging to the team and campaign photography.",
    },
    filters: {
      all: "All",
      store: "Store",
      packaging: "Packaging & Products",
      people: "Team",
      campaign: "Campaigns",
    },
    note: "All photography shown is concept visualization from the CHEFORA brand system, used here for presentation purposes.",
  },

  contact: {
    hero: {
      eyebrow: "Contact",
      title: "Let's talk",
      subtitle:
        "Whether you have a general question or want to explore a partnership, choose the form below that fits your reason for reaching out.",
    },
    tabs: {
      general: "General Inquiry",
      partnership: "Partnership Request",
    },
    generalForm: {
      title: "General inquiry",
      body: "For questions about the brand, media requests, or anything not related to a partnership.",
    },
    partnershipForm: {
      title: "Partnership request",
      body: "For companies exploring an agency, distribution or other commercial partnership with CHEFORA.",
    },
    fields: {
      name: "Full name",
      email: "Email address",
      phone: "Phone number",
      message: "Message",
      companyName: "Company name",
      contactName: "Contact person",
      country: "Country",
      city: "City",
      interest: "Type of interest",
      companyBrief: "About your company",
      submit: "Send",
      submitting: "Sending…",
      interestOptions: {
        agency: "Agency",
        distribution: "Distribution",
        other: "Other partnership",
      },
      placeholders: {
        name: "Your full name",
        email: "you@company.com",
        phone: "+1 555 000 0000",
        message: "How can we help?",
        companyName: "Your company's name",
        contactName: "Name of the person we should contact",
        country: "Country",
        city: "City",
        companyBrief: "A short introduction to your company and markets",
        partnershipMessage: "Tell us more about the partnership you have in mind",
      },
      errors: {
        required: "This field is required.",
        email: "Please enter a valid email address.",
        minLength: "Please provide a little more detail.",
      },
    },
    success: {
      general: "Thank you — your message has been sent. We'll be in touch soon.",
      partnership:
        "Thank you — your partnership request has been received. Our team will review it and follow up.",
    },
    error: "Something went wrong while sending your message. Please try again in a moment.",
    directInfo: {
      title: "Direct contact",
      note: "Official contact details will be added here before launch.",
    },
  },

  privacy: {
    title: "Privacy Policy",
    updated: "Draft — pending legal review",
    intro:
      "This is a draft privacy policy for the CHEFORA website. It explains, in general terms, how information submitted through our contact and partnership forms may be used. This draft should be reviewed and finalized by qualified legal counsel before the site is published.",
    sections: [
      {
        title: "1. Information we collect",
        body: "When you submit a form on this website, we collect the information you provide directly, such as your name, email address, phone number, company details and any message you send us.",
      },
      {
        title: "2. How we use information",
        body: "Information submitted through our forms is used to respond to your inquiry, evaluate partnership requests, and communicate with you about your request.",
      },
      {
        title: "3. Information sharing",
        body: "We do not sell the information you submit. It is used internally to respond to and process your inquiry or request.",
      },
      {
        title: "4. Data retention",
        body: "We retain submitted information for as long as reasonably necessary to respond to your inquiry and for legitimate business record-keeping, unless a longer period is required by law.",
      },
      {
        title: "5. Your choices",
        body: "You may contact us at any time to ask about, update, or request removal of information you have submitted.",
      },
      {
        title: "6. Changes to this policy",
        body: "This policy is a draft and is expected to change before launch and over time as the business evolves.",
      },
    ],
  },

  terms: {
    title: "Terms of Use",
    updated: "Draft — pending legal review",
    intro:
      "This is a draft set of terms of use for the CHEFORA website. It should be reviewed and finalized by qualified legal counsel before the site is published.",
    sections: [
      {
        title: "1. About this website",
        body: "This website presents the CHEFORA brand and provides a way for companies to inquire about partnership opportunities. It does not constitute an offer of any specific agency, distribution or franchise rights.",
      },
      {
        title: "2. Intellectual property",
        body: "The CHEFORA name, logo, brand identity and photography shown on this site are the property of CHEFORA and may not be used without permission.",
      },
      {
        title: "3. No guarantee of partnership",
        body: "Submitting a partnership request through this website does not guarantee a partnership, agency or distribution agreement of any kind. All partnerships are subject to direct discussion and formal agreement.",
      },
      {
        title: "4. Accuracy of information",
        body: "We aim to keep information on this site accurate, but some content — such as specific commercial terms — is confirmed only through direct communication, not through this website.",
      },
      {
        title: "5. Limitation of liability",
        body: "This website and its content are provided as-is. To the extent permitted by law, CHEFORA is not liable for decisions made solely on the basis of this website's content.",
      },
      {
        title: "6. Changes to these terms",
        body: "These terms are a draft and may change before launch and over time.",
      },
    ],
  },

  common: {
    skipToContent: "Skip to content",
    readMore: "Read more",
    backHome: "Back to home",
  },
};

export default en;
export type Dictionary = typeof en;
